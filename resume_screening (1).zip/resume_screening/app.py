import os
import uuid
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file, session
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

from config import config
from models import db, Job, Candidate, ActivityLog, User

app = Flask(__name__)
app.config.from_object(config['development'])

# Initialize database
db.init_app(app)

# Secret key for sessions
app.secret_key = 'resume-screening-secret-key-2025'

# Create upload folder if not exists
UPLOAD_FOLDER = app.config['UPLOAD_FOLDER']
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)


def log_activity(action, description):
    """Log user activity."""
    log = ActivityLog(action=action, description=description)
    db.session.add(log)
    db.session.commit()


def login_required(f):
    """Decorator to require login for routes."""
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login to access this page', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


@app.route('/')
def welcome():
    """Welcome page route."""
    return render_template('welcome.html')


@app.route('/home')
def home():
    """Home/Dashboard route - requires login."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Get statistics
    total_jobs = Job.query.count()
    total_candidates = Candidate.query.count()
    screened_candidates = Candidate.query.filter(Candidate.match_category != 'Not Screened').count()
    
    # Get recent candidates
    recent_candidates = Candidate.query.order_by(Candidate.uploaded_at.desc()).limit(5).all()
    
    # Get recent activity
    recent_activity = ActivityLog.query.order_by(ActivityLog.created_at.desc()).limit(10).all()
    
    # Get candidates by category
    category_stats = {}
    categories = ['Highly Qualified', 'Qualified', 'Needs Improvement', 'Not Qualified', 'Not Screened']
    for cat in categories:
        category_stats[cat] = Candidate.query.filter(Candidate.match_category == cat).count()
    
    return render_template('index.html',
                         total_jobs=total_jobs,
                         total_candidates=total_candidates,
                         screened_candidates=screened_candidates,
                         recent_candidates=recent_candidates,
                         recent_activity=recent_activity,
                         category_stats=category_stats)


@app.route('/')
def index():
    """Dashboard route - requires login."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Get statistics
    total_jobs = Job.query.count()
    total_candidates = Candidate.query.count()
    screened_candidates = Candidate.query.filter(Candidate.match_category != 'Not Screened').count()
    
    # Get recent candidates
    recent_candidates = Candidate.query.order_by(Candidate.uploaded_at.desc()).limit(5).all()
    
    # Get recent activity
    recent_activity = ActivityLog.query.order_by(ActivityLog.created_at.desc()).limit(10).all()
    
    # Get candidates by category
    category_stats = {}
    categories = ['Highly Qualified', 'Qualified', 'Needs Improvement', 'Not Qualified', 'Not Screened']
    for cat in categories:
        category_stats[cat] = Candidate.query.filter(Candidate.match_category == cat).count()
    
    return render_template('index.html',
                         total_jobs=total_jobs,
                         total_candidates=total_candidates,
                         screened_candidates=screened_candidates,
                         recent_candidates=recent_candidates,
                         recent_activity=recent_activity,
                         category_stats=category_stats)


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login route."""
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        # For demo: accept any login
        user = User.query.filter_by(email=email).first()
        
        if user:
            if check_password_hash(user.password, password):
                session['user_id'] = user.id
                session['user_name'] = user.first_name
                session['user_email'] = user.email
                flash(f'Welcome back, {user.first_name}!', 'success')
                return redirect(url_for('index'))
            else:
                flash('Invalid password', 'error')
        else:
            # Create demo user on first login
            new_user = User(
                email=email,
                password=generate_password_hash(password),
                first_name=email.split('@')[0].title(),
                last_name='',
                company='Demo Company'
            )
            db.session.add(new_user)
            db.session.commit()
            session['user_id'] = new_user.id
            session['user_name'] = new_user.first_name
            session['user_email'] = new_user.email
            flash(f'Welcome! Account created successfully.', 'success')
            return redirect(url_for('index'))
    
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    """Register route."""
    if request.method == 'POST':
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        company = request.form.get('company')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if password != confirm_password:
            flash('Passwords do not match', 'error')
            return redirect(url_for('register'))
        
        # Check if user exists
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('Email already registered', 'error')
            return redirect(url_for('register'))
        
        # Create new user
        user = User(
            email=email,
            password=generate_password_hash(password),
            first_name=first_name,
            last_name=last_name,
            phone=phone,
            company=company
        )
        
        db.session.add(user)
        db.session.commit()
        
        flash('Account created successfully! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')


@app.route('/logout')
def logout():
    """Logout route."""
    session.clear()
    flash('You have been logged out successfully', 'success')
    return redirect(url_for('welcome'))


@app.route('/jobs')
@login_required
def jobs():
    """Jobs listing route."""
    all_jobs = Job.query.order_by(Job.created_at.desc()).all()
    return render_template('jobs.html', jobs=all_jobs)


@app.route('/jobs/create', methods=['GET', 'POST'])
@login_required
def create_job():
    """Create new job posting."""
    if request.method == 'POST':
        try:
            title = request.form.get('title')
            company = request.form.get('company')
            description = request.form.get('description')
            required_skills = request.form.get('required_skills')
            experience_required = request.form.get('experience_required')
            
            job = Job(
                title=title,
                company=company,
                description=description,
                required_skills=required_skills,
                experience_required=experience_required
            )
            
            db.session.add(job)
            db.session.commit()
            
            log_activity('Job Created', f'Created job: {title}')
            flash(f'Job "{title}" created successfully!', 'success')
            return redirect(url_for('jobs'))
            
        except Exception as e:
            flash(f'Error creating job: {str(e)}', 'error')
            return redirect(url_for('create_job'))
    
    return render_template('create_job.html')


@app.route('/jobs/<int:job_id>')
@login_required
def job_detail(job_id):
    """Job detail route."""
    job = Job.query.get_or_404(job_id)
    candidates = Candidate.query.filter_by(job_id=job_id).order_by(Candidate.match_percentage.desc()).all()
    return render_template('job_detail.html', job=job, candidates=candidates)


@app.route('/jobs/<int:job_id>/delete', methods=['POST'])
@login_required
def delete_job(job_id):
    """Delete job posting."""
    job = Job.query.get_or_404(job_id)
    try:
        job_title = job.title
        db.session.delete(job)
        db.session.commit()
        log_activity('Job Deleted', f'Deleted job: {job_title}')
        flash(f'Job "{job_title}" deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting job: {str(e)}', 'error')
    
    return redirect(url_for('jobs'))


@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    """Resume upload route."""
    if request.method == 'POST':
        try:
            # Get job selection
            job_id = request.form.get('job_id')
            
            # Check if file was uploaded
            if 'resume' not in request.files:
                flash('No file uploaded', 'error')
                return redirect(request.url)
            
            file = request.files['resume']
            
            if file.filename == '':
                flash('No file selected', 'error')
                return redirect(request.url)
            
            from utils.parser import ResumeParser
            from utils.extractor import InformationExtractor
            
            if file and ResumeParser.allowed_file(file.filename):
                # Generate unique filename
                filename = secure_filename(file.filename)
                unique_filename = f"{uuid.uuid4()}_{filename}"
                file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
                
                # Save file
                file.save(file_path)
                
                # Parse resume
                parsed_text = ResumeParser.parse_resume(file_path)
                parsed_text = ResumeParser.clean_text(parsed_text)
                
                # Extract information
                extracted = InformationExtractor.extract_all(parsed_text)
                
                # Create candidate record
                candidate = Candidate(
                    job_id=job_id if job_id else None,
                    name=extracted.get('name'),
                    email=extracted.get('email'),
                    phone=extracted.get('phone'),
                    file_name=filename,
                    file_path=file_path,
                    parsed_text=parsed_text,
                    skills=', '.join(extracted.get('skills', [])),
                    experience=extracted.get('experience'),
                    education=extracted.get('education'),
                )
                
                db.session.add(candidate)
                db.session.commit()
                
                # If job is selected, automatically screen the candidate
                if job_id:
                    candidate = screen_candidate(candidate.id, job_id)
                
                log_activity('Resume Uploaded', f'Uploaded resume: {filename}')
                flash(f'Resume "{filename}" uploaded successfully!', 'success')
                
                if job_id:
                    return redirect(url_for('job_detail', job_id=job_id))
                else:
                    return redirect(url_for('candidates'))
            
            else:
                flash('Invalid file type. Please upload PDF or DOCX files.', 'error')
                return redirect(request.url)
                
        except Exception as e:
            flash(f'Error uploading resume: {str(e)}', 'error')
            return redirect(request.url)
    
    # Get all jobs for selection
    all_jobs = Job.query.all()
    return render_template('upload.html', jobs=all_jobs)


def screen_candidate(candidate_id, job_id):
    """Screen candidate against a job."""
    from utils.matcher import ResumeMatcher
    
    candidate = Candidate.query.get_or_404(candidate_id)
    job = Job.query.get_or_404(job_id)
    
    try:
        # Parse skills
        candidate_skills = candidate.skills.split(', ') if candidate.skills else []
        
        # Calculate match
        match_percentage, category, matched_skills, missing_skills = ResumeMatcher.calculate_match(
            candidate_skills=candidate_skills,
            job_skills=job.required_skills,
            candidate_experience=candidate.experience,
            job_experience=job.experience_required,
            resume_text=candidate.parsed_text,
            job_description=job.description
        )
        
        # Update candidate
        candidate.job_id = job_id
        candidate.match_percentage = match_percentage
        candidate.match_category = category
        candidate.matched_skills = ', '.join(matched_skills)
        candidate.missing_skills = ', '.join(missing_skills)
        candidate.screened_at = datetime.utcnow()
        
        db.session.commit()
        
        log_activity('Candidate Screened', f'Screened {candidate.name or candidate.file_name} for {job.title}')
        
        return candidate
        
    except Exception as e:
        flash(f'Error screening candidate: {str(e)}', 'error')
        return candidate


@app.route('/candidates')
@login_required
def candidates():
    """Candidates listing route."""
    search = request.args.get('search', '')
    category = request.args.get('category', '')
    job_id = request.args.get('job_id', '')
    
    query = Candidate.query
    
    if search:
        query = query.filter(
            (Candidate.name.ilike(f'%{search}%')) |
            (Candidate.email.ilike(f'%{search}%')) |
            (Candidate.file_name.ilike(f'%{search}%'))
        )
    
    if category:
        query = query.filter(Candidate.match_category == category)
    
    if job_id:
        query = query.filter(Candidate.job_id == job_id)
    
    all_candidates = query.order_by(Candidate.uploaded_at.desc()).all()
    all_jobs = Job.query.all()
    
    return render_template('candidates.html', 
                         candidates=all_candidates, 
                         jobs=all_jobs,
                         search=search,
                         category=category,
                         selected_job=job_id)


@app.route('/candidates/<int:candidate_id>')
@login_required
def candidate_detail(candidate_id):
    """Candidate detail route."""
    candidate = Candidate.query.get_or_404(candidate_id)
    job = Job.query.get(candidate.job_id) if candidate.job_id else None
    return render_template('candidate_detail.html', candidate=candidate, job=job)


@app.route('/candidates/<int:candidate_id>/screen/<int:job_id>', methods=['POST'])
@login_required
def screen_candidate_route(candidate_id, job_id):
    """Screen candidate route."""
    try:
        candidate = screen_candidate(candidate_id, job_id)
        flash(f'Candidate screened successfully! Match: {candidate.match_percentage}%', 'success')
    except Exception as e:
        flash(f'Error screening candidate: {str(e)}', 'error')
    
    return redirect(url_for('candidate_detail', candidate_id=candidate_id))


@app.route('/candidates/<int:candidate_id>/delete', methods=['POST'])
@login_required
def delete_candidate(candidate_id):
    """Delete candidate."""
    candidate = Candidate.query.get_or_404(candidate_id)
    try:
        # Delete file if exists
        if candidate.file_path and os.path.exists(candidate.file_path):
            os.remove(candidate.file_path)
        
        candidate_name = candidate.name or candidate.file_name
        db.session.delete(candidate)
        db.session.commit()
        
        log_activity('Candidate Deleted', f'Deleted candidate: {candidate_name}')
        flash(f'Candidate deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting candidate: {str(e)}', 'error')
    
    return redirect(url_for('candidates'))


@app.route('/screen-all/<int:job_id>', methods=['POST'])
@login_required
def screen_all_candidates(job_id):
    """Screen all candidates for a job."""
    job = Job.query.get_or_404(job_id)
    
    try:
        # Get all candidates without screening for this job
        candidates = Candidate.query.filter(
            (Candidate.job_id == None) | 
            (Candidate.job_id != job_id)
        ).all()
        
        screened_count = 0
        for candidate in candidates:
            screen_candidate(candidate.id, job_id)
            screened_count += 1
        
        log_activity('Bulk Screening', f'Screened {screened_count} candidates for {job.title}')
        flash(f'Screened {screened_count} candidates for {job.title}!', 'success')
        
    except Exception as e:
        flash(f'Error screening candidates: {str(e)}', 'error')
    
    return redirect(url_for('job_detail', job_id=job_id))


@app.route('/export/<int:job_id>')
@login_required
def export_results(job_id):
    """Export results to CSV."""
    import csv
    
    job = Job.query.get_or_404(job_id)
    candidates = Candidate.query.filter_by(job_id=job_id).order_by(Candidate.match_percentage.desc()).all()
    
    # Create CSV
    csv_filename = f"{job.title.replace(' ', '_')}_candidates.csv"
    csv_path = os.path.join(UPLOAD_FOLDER, csv_filename)
    
    with open(csv_path, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = ['Name', 'Email', 'Phone', 'Match %', 'Category', 'Matched Skills', 'Missing Skills', 'Uploaded At']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        for candidate in candidates:
            writer.writerow({
                'Name': candidate.name or 'N/A',
                'Email': candidate.email or 'N/A',
                'Phone': candidate.phone or 'N/A',
                'Match %': candidate.match_percentage,
                'Category': candidate.match_category,
                'Matched Skills': candidate.matched_skills or 'N/A',
                'Missing Skills': candidate.missing_skills or 'N/A',
                'Uploaded At': candidate.uploaded_at.strftime('%Y-%m-%d %H:%M:%S')
            })
    
    log_activity('Results Exported', f'Exported candidates for {job.title}')
    
    return send_file(csv_path, as_attachment=True, download_name=csv_filename)


# API Routes
@app.route('/api/stats')
@login_required
def api_stats():
    """API endpoint for dashboard statistics."""
    total_jobs = Job.query.count()
    total_candidates = Candidate.query.count()
    screened = Candidate.query.filter(Candidate.match_category != 'Not Screened').count()
    
    # Category distribution
    categories = {}
    for cat in ['Highly Qualified', 'Qualified', 'Needs Improvement', 'Not Qualified']:
        categories[cat] = Candidate.query.filter(Candidate.match_category == cat).count()
    
    return jsonify({
        'total_jobs': total_jobs,
        'total_candidates': total_candidates,
        'screened_candidates': screened,
        'category_distribution': categories
    })


# Error handlers
@app.errorhandler(404)
def not_found_error(error):
    return render_template('error.html', error='Page not found'), 404


@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('error.html', error='Internal server error'), 500


# Initialize database
with app.app_context():
    db.create_all()


if __name__ == '__main__':
    app.run(debug=True, port=5000)

