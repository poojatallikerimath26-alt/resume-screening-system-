import re
from typing import Dict, List, Tuple


class ResumeMatcher:
    """Utility class for matching resumes with job requirements."""
    
    # Category thresholds
    HIGHLY_QUALIFIED_THRESHOLD = 75
    QUALIFIED_THRESHOLD = 50
    NEEDS_IMPROVEMENT_THRESHOLD = 25
    
    # Weights for different matching criteria
    SKILL_WEIGHT = 0.50
    EXPERIENCE_WEIGHT = 0.30
    KEYWORD_WEIGHT = 0.20
    
    @staticmethod
    def calculate_match(candidate_skills: List[str], job_skills: str, 
                        candidate_experience: str, job_experience: str,
                        resume_text: str, job_description: str) -> Tuple[float, str, List[str], List[str]]:
        """
        Calculate match percentage between candidate and job.
        
        Returns:
            Tuple of (match_percentage, category, matched_skills, missing_skills)
        """
        # Parse job skills
        job_skill_list = ResumeMatcher._parse_job_skills(job_skills)
        
        # Calculate skill match
        skill_score, matched_skills, missing_skills = ResumeMatcher._calculate_skill_match(
            candidate_skills, job_skill_list
        )
        
        # Calculate experience match
        experience_score = ResumeMatcher._calculate_experience_match(
            candidate_experience, job_experience
        )
        
        # Calculate keyword match
        keyword_score = ResumeMatcher._calculate_keyword_match(
            resume_text, job_description, job_skill_list
        )
        
        # Calculate weighted overall score
        overall_score = (
            skill_score * ResumeMatcher.SKILL_WEIGHT +
            experience_score * ResumeMatcher.EXPERIENCE_WEIGHT +
            keyword_score * ResumeMatcher.KEYWORD_WEIGHT
        )
        
        # Round to 2 decimal places
        overall_score = round(overall_score, 2)
        
        # Determine category
        category = ResumeMatcher._get_category(overall_score)
        
        return overall_score, category, matched_skills, missing_skills
    
    @staticmethod
    def _parse_job_skills(job_skills: str) -> List[str]:
        """Parse job skills from string to list."""
        if not job_skills:
            return []
        
        # Split by common delimiters
        skills = re.split(r'[,;|\n]+', job_skills.lower())
        
        # Clean and filter
        cleaned_skills = []
        for skill in skills:
            skill = skill.strip()
            if skill and len(skill) > 1:
                cleaned_skills.append(skill)
        
        return cleaned_skills
    
    @staticmethod
    def _calculate_skill_match(candidate_skills: List[str], job_skills: List[str]) -> Tuple[float, List[str], List[str]]:
        """Calculate skill match score."""
        if not job_skills:
            return 100.0, [], []
        
        if not candidate_skills:
            return 0.0, [], job_skills
        
        # Normalize candidate skills
        candidate_skills_lower = [s.lower() for s in candidate_skills]
        
        # Find matched and missing skills
        matched_skills = []
        missing_skills = []
        
        for job_skill in job_skills:
            found = False
            for cand_skill in candidate_skills_lower:
                # Check for exact match or partial match
                if job_skill in cand_skill or cand_skill in job_skill:
                    matched_skills.append(job_skill.title())
                    found = True
                    break
            
            if not found:
                missing_skills.append(job_skill.title())
        
        # Calculate score
        if len(job_skills) > 0:
            score = (len(matched_skills) / len(job_skills)) * 100
        else:
            score = 100.0
        
        return round(score, 2), matched_skills, missing_skills
    
    @staticmethod
    def _calculate_experience_match(candidate_experience: str, job_experience: str) -> float:
        """Calculate experience match score."""
        # Extract years of experience
        cand_years = ResumeMatcher._extract_years(candidate_experience or "")
        req_years = ResumeMatcher._extract_years(job_experience or "")
        
        if not req_years:
            return 50.0  # Neutral score if no requirement specified
        
        if not cand_years:
            return 0.0
        
        # Calculate score based on ratio
        if cand_years >= req_years:
            return 100.0
        else:
            ratio = cand_years / req_years
            return min(100.0, ratio * 100)
    
    @staticmethod
    def _extract_years(text: str) -> float:
        """Extract years of experience from text."""
        if not text:
            return 0.0
        
        # Look for patterns like "5 years", "3+ years", "2-4 years"
        patterns = [
            r'(\d+)\+?\s*(?:years?|yrs?)',
            r'(\d+)\s*-\s*\d+\s*(?:years?|yrs?)',
            r'at least (\d+)\s*(?:years?|yrs?)',
            r'minimum (\d+)\s*(?:years?|yrs?)',
        ]
        
        max_years = 0.0
        for pattern in patterns:
            match = re.search(pattern, text.lower())
            if match:
                years = float(match.group(1))
                max_years = max(max_years, years)
        
        return max_years
    
    @staticmethod
    def _calculate_keyword_match(resume_text: str, job_description: str, job_skills: List[str]) -> float:
        """Calculate keyword match score from job description."""
        if not job_description:
            return 50.0  # Neutral score
        
        if not resume_text:
            return 0.0
        
        # Get keywords from job description
        job_keywords = ResumeMatcher._extract_keywords(job_description)
        
        # Add job skills to keywords
        for skill in job_skills:
            if skill not in job_keywords:
                job_keywords.append(skill)
        
        if not job_keywords:
            return 50.0
        
        # Count matches in resume
        resume_lower = resume_text.lower()
        matches = 0
        
        for keyword in job_keywords:
            if keyword.lower() in resume_lower:
                matches += 1
        
        return (matches / len(job_keywords)) * 100
    
    @staticmethod
    def _extract_keywords(text: str) -> List[str]:
        """Extract important keywords from text."""
        # Common stop words to ignore
        stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been',
            'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
            'could', 'should', 'may', 'might', 'must', 'shall', 'can', 'need',
            'dare', 'ought', 'used', 'it', 'its', 'this', 'that', 'these',
            'those', 'i', 'you', 'he', 'she', 'we', 'they', 'what', 'which',
            'who', 'whom', 'whose', 'where', 'when', 'why', 'how', 'all', 'each',
            'every', 'both', 'few', 'more', 'most', 'other', 'some', 'such', 'no',
            'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's',
            't', 'just', 'don', 'now', 'also', 'back', 'even', 'still', 'well',
            'much', 'many', 'any', 'about', 'into', 'over', 'after', 'before',
            'between', 'under', 'again', 'here', 'there', 'work', 'working',
            'job', 'experience', 'years', 'year', 'candidate', 'applicant',
        }
        
        # Extract words
        words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
        
        # Filter and return unique keywords
        keywords = []
        for word in words:
            if word not in stop_words and word not in keywords:
                keywords.append(word)
        
        return keywords
    
    @staticmethod
    def _get_category(score: float) -> str:
        """Determine category based on score."""
        if score >= ResumeMatcher.HIGHLY_QUALIFIED_THRESHOLD:
            return "Highly Qualified"
        elif score >= ResumeMatcher.QUALIFIED_THRESHOLD:
            return "Qualified"
        elif score >= ResumeMatcher.NEEDS_IMPROVEMENT_THRESHOLD:
            return "Needs Improvement"
        else:
            return "Not Qualified"
    
    @staticmethod
    def get_category_color(category: str) -> str:
        """Get color for category badge."""
        colors = {
            "Highly Qualified": "#22c55e",  # Green
            "Qualified": "#3b82f6",         # Blue
            "Needs Improvement": "#f59e0b", # Orange
            "Not Qualified": "#ef4444",     # Red
            "Not Screened": "#6b7280",      # Gray
        }
        return colors.get(category, "#6b7280")

