import os
import re
from pathlib import Path


class ResumeParser:
    """Utility class for parsing resumes from various file formats."""
    
    @staticmethod
    def allowed_file(filename):
        """Check if file extension is allowed."""
        allowed_extensions = {'pdf', 'docx', 'doc'}
        return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions
    
    @staticmethod
    def parse_resume(file_path):
        """Parse resume and extract text based on file type."""
        file_extension = os.path.splitext(file_path)[1].lower()
        
        if file_extension == '.pdf':
            return ResumeParser._parse_pdf(file_path)
        elif file_extension in ['.docx', '.doc']:
            return ResumeParser._parse_docx(file_path)
        else:
            raise ValueError(f"Unsupported file format: {file_extension}")
    
    @staticmethod
    def _parse_pdf(file_path):
        """Parse PDF file and extract text."""
        text = ""
        try:
            import PyPDF2
            with open(file_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                for page in pdf_reader.pages:
                    text += page.extract_text() + "\n"
        except ImportError:
            # Fallback to pdfplumber if PyPDF2 is not available
            try:
                import pdfplumber
                with pdfplumber.open(file_path) as pdf:
                    for page in pdf.pages:
                        text += page.extract_text() + "\n"
            except ImportError:
                raise ImportError("Please install PyPDF2 or pdfplumber to parse PDF files")
        
        return text
    
    @staticmethod
    def _parse_docx(file_path):
        """Parse DOCX file and extract text."""
        try:
            from docx import Document
            doc = Document(file_path)
            text = ""
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            # Also extract text from tables if any
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        text += cell.text + "\n"
            return text
        except ImportError:
            raise ImportError("Please install python-docx to parse DOCX files")
    
    @staticmethod
    def clean_text(text):
        """Clean and normalize extracted text."""
        if not text:
            return ""
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove special characters but keep essential punctuation
        text = re.sub(r'[^\w\s@.-]', ' ', text)
        
        # Trim leading/trailing whitespace
        text = text.strip()
        
        return text
    
    @staticmethod
    def get_file_size(file_path):
        """Get file size in MB."""
        size_bytes = os.path.getsize(file_path)
        size_mb = size_bytes / (1024 * 1024)
        return round(size_mb, 2)

