import re
from typing import Dict, List, Optional


class InformationExtractor:
    """Utility class for extracting information from parsed resume text."""
    
    # Common email pattern
    EMAIL_PATTERN = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    
    # Common phone patterns (international and US formats)
    PHONE_PATTERNS = [
        r'\+?1?\s*[-.]?\s*\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}',
        r'\+?[0-9]{1,4}[-.\s]?[0-9]{2,4}[-.\s]?[0-9]{2,4}[-.\s]?[0-9]{2,4}',
        r'\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}',
    ]
    
    # Technical skills keywords
    TECHNICAL_SKILLS = [
        'python', 'java', 'javascript', 'c++', 'c#', 'ruby', 'go', 'rust', 'scala', 'kotlin',
        'swift', 'objective-c', 'php', 'perl', 'r', 'matlab', 'sql', 'html', 'css', 'xml',
        'json', 'yaml', 'typescript', 'bash', 'shell', 'powershell', 'docker', 'kubernetes',
        'jenkins', 'git', 'github', 'gitlab', 'bitbucket', 'jira', 'confluence',
        'aws', 'azure', 'gcp', 'google cloud', 'amazon web services',
        'react', 'angular', 'vue', 'node.js', 'django', 'flask', 'spring', 'laravel',
        'express', 'next.js', 'nuxt', 'svelte', 'bootstrap', 'tailwind', 'sass', 'less',
        'mongodb', 'mysql', 'postgresql', 'oracle', 'redis', 'elasticsearch', 'cassandra',
        'hadoop', 'spark', 'hive', 'kafka', 'RabbitMQ', 'rest api', 'graphql',
        'machine learning', 'deep learning', 'tensorflow', 'pytorch', 'keras', 'scikit-learn',
        'nlp', 'natural language processing', 'computer vision', 'opencv', 'pandas', 'numpy',
        'scipy', 'matplotlib', 'seaborn', 'tableau', 'power bi', 'excel', 'statistics',
        'data analysis', 'data visualization', 'data mining', 'etl', 'data warehouse',
        'snowflake', 'databricks', 'airflow', ' Luigi', 'terraform', 'ansible', 'puppet',
        'ci/cd', 'devops', 'agile', 'scrum', 'jira', 'kanban', 'uml', 'rest', 'soap',
        'microservices', 'architecture', 'design patterns', 'oops', 'mvc', 'api',
        'linux', 'unix', 'windows server', 'networking', 'security', 'cybersecurity',
        'penetration testing', 'firewall', 'vpn', 'ssl', 'tls', 'http', 'https', 'tcp/ip',
        'dns', 'dhcp', 'smtp', 'pop3', 'imap', 'ftp', 'ssh', 'telnet', 'vcs',
        'project management', 'team leadership', 'communication', 'problem solving',
        'analytical', 'creative', 'time management', 'adaptable', 'collaborative',
        'leadership', 'mentoring', 'presentation', 'technical writing', 'research',
        'agile methodology', 'waterfall', 'testing', 'unit testing', 'integration testing',
        'selenium', 'appium', 'jmeter', 'postman', 'load testing', 'performance testing',
        'automation', 'robotics', 'iot', 'blockchain', 'ethereum', 'solidity', 'web3',
        'flutter', 'react native', 'xamarin', 'ionic', 'mobile development', 'android', 'ios',
        'restful', 'graphql', 'grpc', 'websockets', 'sockets.io', 'http/2', 'cdn',
        'cache', 'redis', 'memcached', 'varnish', 'nginx', 'apache', 'tomcat', 'iis',
        'load balancing', 'horizontal scaling', 'vertical scaling', 'cloudflare',
        's3', 'ec2', 'lambda', 'ecs', 'eks', 'rds', 'dynamodb', 'sqs', 'sns', 'cloudwatch',
        'iam', 'vpc', 'route53', 'elb', 'aurora', 'redshift', 'glue', 'athena', 'quicksight',
    ]
    
    # Soft skills keywords
    SOFT_SKILLS = [
        'communication', 'leadership', 'teamwork', 'problem solving', 'analytical',
        'creative', 'time management', 'adaptable', 'flexible', 'detail oriented',
        'organized', 'self motivated', 'independent', 'collaborative', 'team player',
        'presentation', 'public speaking', 'writing', 'documentation', 'interpersonal',
        'conflict resolution', 'negotiation', 'decision making', 'critical thinking',
        'strategic planning', 'project management', 'stakeholder management',
        'customer service', 'client relations', 'mentoring', 'coaching', 'training',
    ]
    
    # Education keywords
    EDUCATION_KEYWORDS = [
        'bachelor', 'master', 'phd', 'doctorate', 'diploma', 'certificate', 'degree',
        'computer science', 'information technology', 'software engineering',
        'data science', 'artificial intelligence', 'machine learning',
        'electronics', 'electrical', 'mechanical', 'civil', 'chemical',
        'physics', 'mathematics', 'statistics', 'economics', 'business',
        'mba', 'btech', 'mtech', 'bca', 'mca', 'bsc', 'msc', 'be', 'me',
        'university', 'college', 'institute', 'school', 'academy',
    ]
    
    # Experience patterns
    EXPERIENCE_PATTERNS = [
        r'(\d+)\+?\s*(years?|yrs?)\s*(of\s*)?(experience|exp)?',
        r'(\d+)\s*-\s*(\d+)\s*(years?|yrs?)\s*(experience|exp)?',
        r'(fresher|entry.?level|junior|mid.?level|senior|lead|principal|staff)',
    ]
    
    @staticmethod
    def extract_email(text: str) -> Optional[str]:
        """Extract email address from text."""
        match = re.search(InformationExtractor.EMAIL_PATTERN, text)
        return match.group(0) if match else None
    
    @staticmethod
    def extract_phone(text: str) -> Optional[str]:
        """Extract phone number from text."""
        for pattern in InformationExtractor.PHONE_PATTERNS:
            match = re.search(pattern, text)
            if match:
                return match.group(0)
        return None
    
    @staticmethod
    def extract_name(text: str) -> Optional[str]:
        """Extract candidate name from text."""
        lines = text.split('\n')
        
        # Usually name is in the first few lines
        # and is typically a short line without special characters
        for line in lines[:5]:
            line = line.strip()
            # Check if line looks like a name (2-4 words, mostly letters)
            if 2 <= len(line.split()) <= 4:
                words = line.split()
                if all(word.isalpha() and len(word) > 1 for word in words):
                    # Skip lines that look like titles or headers
                    title_keywords = ['resume', 'cv', 'curriculum', 'vitae', 'profile', 'summary']
                    if any(keyword in line.lower() for keyword in title_keywords):
                        continue
                    return line.title()
        
        return None
    
    @staticmethod
    def extract_skills(text: str) -> List[str]:
        """Extract skills from resume text."""
        text_lower = text.lower()
        found_skills = []
        
        # Check for technical skills
        for skill in InformationExtractor.TECHNICAL_SKILLS:
            if skill in text_lower:
                found_skills.append(skill.title() if len(skill) > 3 else skill.upper())
        
        # Check for soft skills
        for skill in InformationExtractor.SOFT_SKILLS:
            if skill in text_lower:
                found_skills.append(skill.title())
        
        # Remove duplicates while preserving order
        seen = set()
        unique_skills = []
        for skill in found_skills:
            if skill.lower() not in seen:
                seen.add(skill.lower())
                unique_skills.append(skill)
        
        return unique_skills
    
    @staticmethod
    def extract_experience(text: str) -> Optional[str]:
        """Extract work experience from text."""
        text_lower = text.lower()
        
        # Look for experience patterns
        for pattern in InformationExtractor.EXPERIENCE_PATTERNS:
            match = re.search(pattern, text_lower)
            if match:
                return match.group(0)
        
        # Try to find experience section
        experience_keywords = ['experience', 'work history', 'employment', 'professional experience']
        for keyword in experience_keywords:
            if keyword in text_lower:
                # Find the section and extract a snippet
                idx = text_lower.find(keyword)
                section = text[idx:idx+500]
                return section.strip()
        
        return None
    
    @staticmethod
    def extract_education(text: str) -> Optional[str]:
        """Extract education details from text."""
        text_lower = text.lower()
        
        # Look for education-related sections
        education_sections = ['education', 'academic', 'qualification', 'degree']
        
        for keyword in education_sections:
            if keyword in text_lower:
                idx = text_lower.find(keyword)
                # Get text after the keyword
                section = text[idx:idx+800]
                return section.strip()
        
        # Check for degree mentions
        degrees = []
        for degree in InformationExtractor.EDUCATION_KEYWORDS:
            if degree in text_lower:
                # Find the full context
                idx = text_lower.find(degree)
                context = text[max(0, idx-20):min(len(text), idx+50)]
                if context not in degrees:
                    degrees.append(context.strip())
        
        if degrees:
            return ' | '.join(degrees[:3])
        
        return None
    
    @staticmethod
    def extract_all(text: str) -> Dict[str, any]:
        """Extract all information from resume text."""
        return {
            'name': InformationExtractor.extract_name(text),
            'email': InformationExtractor.extract_email(text),
            'phone': InformationExtractor.extract_phone(text),
            'skills': InformationExtractor.extract_skills(text),
            'experience': InformationExtractor.extract_experience(text),
            'education': InformationExtractor.extract_education(text),
        }

