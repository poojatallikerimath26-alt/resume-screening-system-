from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()


class Job(db.Model):
    """Job posting model."""
    __tablename__ = 'jobs'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    company = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    required_skills = db.Column(db.Text, nullable=True)
    experience_required = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    candidates = db.relationship('Candidate', backref='job', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        """Convert job to dictionary."""
        return {
            'id': self.id,
            'title': self.title,
            'company': self.company,
            'description': self.description,
            'required_skills': self.required_skills,
            'experience_required': self.experience_required,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S'),
            'candidate_count': len(self.candidates)
        }


class Candidate(db.Model):
    """Candidate/Resume model."""
    __tablename__ = 'candidates'
    
    id = db.Column(db.Integer, primary_key=True)
    job_id = db.Column(db.Integer, db.ForeignKey('jobs.id'), nullable=True)
    
    # Personal Information
    name = db.Column(db.String(200), nullable=True)
    email = db.Column(db.String(200), nullable=True)
    phone = db.Column(db.String(50), nullable=True)
    
    # Resume Data
    file_name = db.Column(db.String(500), nullable=False)
    file_path = db.Column(db.String(500), nullable=False)
    parsed_text = db.Column(db.Text, nullable=True)
    
    # Extracted Information
    skills = db.Column(db.Text, nullable=True)
    experience = db.Column(db.Text, nullable=True)
    education = db.Column(db.Text, nullable=True)
    
    # Matching Results
    match_percentage = db.Column(db.Float, default=0.0)
    match_category = db.Column(db.String(50), default='Not Screened')
    matched_skills = db.Column(db.Text, nullable=True)
    missing_skills = db.Column(db.Text, nullable=True)
    
    # Timestamps
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    screened_at = db.Column(db.DateTime, nullable=True)
    
    def to_dict(self):
        """Convert candidate to dictionary."""
        return {
            'id': self.id,
            'job_id': self.job_id,
            'name': self.name,
            'email': self.email,
            'phone': self.phone,
            'file_name': self.file_name,
            'skills': self.skills,
            'experience': self.experience,
            'education': self.education,
            'match_percentage': self.match_percentage,
            'match_category': self.match_category,
            'matched_skills': self.matched_skills,
            'missing_skills': self.missing_skills,
            'uploaded_at': self.uploaded_at.strftime('%Y-%m-%d %H:%M:%S'),
            'screened_at': self.screened_at.strftime('%Y-%m-%d %H:%M:%S') if self.screened_at else None
        }


class ActivityLog(db.Model):
    """Activity log for tracking user actions."""
    __tablename__ = 'activity_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    action = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        """Convert activity log to dictionary."""
        return {
            'id': self.id,
            'action': self.action,
            'description': self.description,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }


class User(db.Model):
    """User model for authentication."""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(200), unique=True, nullable=False)
    password = db.Column(db.String(500), nullable=False)
    first_name = db.Column(db.String(100), nullable=True)
    last_name = db.Column(db.String(100), nullable=True)
    phone = db.Column(db.String(50), nullable=True)
    company = db.Column(db.String(200), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        """Convert user to dictionary."""
        return {
            'id': self.id,
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'phone': self.phone,
            'company': self.company,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }

